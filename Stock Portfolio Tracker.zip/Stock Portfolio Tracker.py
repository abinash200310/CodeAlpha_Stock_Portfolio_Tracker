stock_prices = {
    "AAPL": 180,
    "TSLA": 250,
    "GOOG": 2700,
    "MSFT": 320,
    "AMZN": 3300
}

portfolio = {}

while True:
    stock = input("Enter stock symbol (AAPL, TSLA, etc): ").upper()
    if stock not in stock_prices:
        print("Stock not found. Try again.")
        continue
    qty = int(input(f"Enter quantity of {stock} shares: "))
    portfolio[stock] = qty

    more = input("Add more stocks? (yes/no): ").lower()
    if more != "yes":
        break

total_value = 0
print("\nYour Stock Portfolio:")
for stock, qty in portfolio.items():
    price = stock_prices[stock]
    value = price * qty
    total_value += value
    print(f"{stock}: {qty} shares x ${price} = ${value}")

# Optional: Save to file
with open("portfolio.txt", "w") as file:
    file.write("Stock Portfolio Summary\n")
    for stock, qty in portfolio.items():
        price = stock_prices[stock]
        value = price * qty
        file.write(f"{stock}: {qty} shares x ${price} = ${value}\n")
    file.write(f"\nTotal Investment: ${total_value}")

print(f"\n💰 Total Investment Value: ${total_value}")
